package zakjo.studentsapp.model;

public class GroupMembers {


    public String phone;


    public GroupMembers() { }

    public GroupMembers(String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}