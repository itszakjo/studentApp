package zakjo.studentsapp.Helpers;

import android.view.View;

public interface ItemClickListenter {

    void onClick(View view);

}

