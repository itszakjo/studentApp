package zakjo.studentsapp.model;

import java.util.List;

public class MyResponse {
    public long multicast_id ;
    public int success,failure, cononical_ids;
    public List<Result> results;
}
