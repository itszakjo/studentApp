package zakjo.studentsapp.model;

public class Days {





    public int id ;
    public String day ;





    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }
}
